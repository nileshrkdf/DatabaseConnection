//
//  DBConnectionClass.h
//  DatabaseConnection
//
//  Created by Nilesh Malviya on 19/07/15.
//  Copyright (c) 2015 KM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface DBConnectionClass : NSObject
+ (NSString *)createDatabase;
+ (NSString *)saveData:(NSDictionary *)dictionary;
+ (NSMutableArray *)searchContactDetails:(NSString *)name;
+ (BOOL) deleteContact:(NSString *)name;
+ (BOOL)updateContact:(NSDictionary *)dictionary;
@end
