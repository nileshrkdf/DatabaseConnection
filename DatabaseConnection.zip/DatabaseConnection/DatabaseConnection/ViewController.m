//
//  ViewController.m
//  DatabaseConnection
//
//  Created by Nilesh Malviya on 19/07/15.
//  Copyright (c) 2015 KM. All rights reserved.
//

#import "ViewController.h"
#import "DBConnectionClass.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [DBConnectionClass createDatabase];
    NSDictionary *dic =  [[NSDictionary alloc]initWithObjects:[[NSArray alloc] initWithObjects:@"Nilesh",@"HI",@"9004403272", nil] forKeys:[[NSArray alloc] initWithObjects:@"name",@"address",@"phone", nil]];
    [DBConnectionClass saveData:dic];
    
     NSDictionary *dic2 =  [[NSDictionary alloc]initWithObjects:[[NSArray alloc] initWithObjects:@"k",@"M",@"848454588548", nil] forKeys:[[NSArray alloc] initWithObjects:@"name",@"address",@"phone", nil]];
    [DBConnectionClass saveData:dic2];
    
    [DBConnectionClass searchContactDetails:@"Nilesh"];
    [DBConnectionClass deleteContact:@"Nilesh"];
    
    NSDictionary *dic1 =  [[NSDictionary alloc]initWithObjects:[[NSArray alloc] initWithObjects:@"K",@"malviya",@"9893308779", nil] forKeys:[[NSArray alloc] initWithObjects:@"name",@"address",@"phone", nil]];
    [DBConnectionClass updateContact:dic1];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
