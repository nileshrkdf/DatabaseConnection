//
//  DBConnectionClass.m
//  DatabaseConnection
//
//  Created by Nilesh Malviya on 19/07/15.
//  Copyright (c) 2015 KM. All rights reserved.
//

#import "DBConnectionClass.h"

static NSString *databasePath;
static sqlite3 *friendDB;

@implementation DBConnectionClass
+ (NSString *)createDatabase{
    
    //get the DB file path
    databasePath = [DBConnectionClass documentDirectoryPath];
    
    // Build the path to the database file
    NSFileManager *filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: databasePath ] == NO)
    {
        const char *dbpath = [databasePath UTF8String];
        
        if (sqlite3_open(dbpath, &friendDB) == SQLITE_OK)
        {
            char *errMsg;
            const char *sql_stmt =
            "CREATE TABLE IF NOT EXISTS CONTACTS (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, ADDRESS TEXT, PHONE TEXT)";
            
            if (sqlite3_exec(friendDB, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK)
            {
                sqlite3_close(friendDB);
                return @"Failed to create table";
            }else{
                sqlite3_close(friendDB);
                return @"Success to create table";
            }
        } else {
                return @"Failed to open/create database";
        }
    }else
        return @"Database file already exists.";
}
+ (NSString *)documentDirectoryPath{
    NSString *docsDir;
    NSArray *dirPaths;
    // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    databasePath = [[NSString alloc]
                     initWithString: [docsDir stringByAppendingPathComponent:
                                      @"Friends.db"]];
    return databasePath;
}
+ (NSString *)saveData:(NSDictionary *)dictionary {
    sqlite3_stmt    *statement;
    const char *dbpath = [databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &friendDB) == SQLITE_OK)
    {
        
        NSString *insertSQL = [NSString stringWithFormat:
                               @"INSERT INTO CONTACTS (name, address, phone) VALUES (\"%@\", \"%@\", \"%@\")",
                               [dictionary valueForKey:@"name"], [dictionary valueForKey:@"address"], [dictionary valueForKey:@"phone"]];
        
        const char *insert_stmt = [insertSQL UTF8String];
        sqlite3_prepare_v2(friendDB, insert_stmt,
                           -1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE)
        {
            sqlite3_finalize(statement);
            sqlite3_close(friendDB);
            return @"Contact added";
            
        } else {
            sqlite3_finalize(statement);
            sqlite3_close(friendDB);

            return @"Failed to add contact";
        }
    }else{
       return @"Not able to open database.";
    }
}
+ (NSMutableArray *)searchContactDetails:(NSString *)name {
    const char *dbpath = [databasePath UTF8String];
    NSMutableArray *resultSet = [[NSMutableArray alloc]init];
    sqlite3_stmt    *statement;
    if (sqlite3_open(dbpath, &friendDB) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat: @"SELECT * FROM contacts WHERE name like '%@%%'",
                              name];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(friendDB, query_stmt, -1, &statement, NULL) == SQLITE_OK)
        {
            while(sqlite3_step(statement) == SQLITE_ROW)
            {
                NSMutableArray *array = [[NSMutableArray alloc]init];
                [array addObject:[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 1)]];
                [array addObject:[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 2)]];
                [array addObject:[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 3)]];
                [resultSet addObject:array];
            }
            sqlite3_finalize(statement);
        }
        sqlite3_close(friendDB);
    }
    return resultSet;
}
+ (BOOL) deleteContact:(NSString *)name
{
    BOOL success = false;
    sqlite3_stmt *statement = NULL;
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &friendDB) == SQLITE_OK)
    {
            NSString *deleteSQL = [NSString stringWithFormat:@"DELETE from contacts WHERE name = '%@'",name];
            const char *delete_stmt = [deleteSQL UTF8String];
            sqlite3_prepare_v2(friendDB, delete_stmt, -1, &statement, NULL );
            if (sqlite3_step(statement) == SQLITE_DONE)
            {
                success = true;
            }
    }else{
            NSLog(@"New data, Nothing to delete");
            success = true;
        }
        sqlite3_finalize(statement);
        sqlite3_close(friendDB);
    return success;
}
+ (BOOL)updateContact:(NSDictionary *)dictionary
{
    BOOL success = false;
    sqlite3_stmt *statement = NULL;
    const char *dbpath = [databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &friendDB) == SQLITE_OK)
    {
        NSString *updateSQL = [NSString stringWithFormat:@"UPDATE contacts set name = '%@', address = '%@', phone = '%@' WHERE name = '%@'",
                               [dictionary valueForKey:@"name"],
                               [dictionary valueForKey:@"address"],
                               [dictionary valueForKey:@"phone"],[dictionary valueForKey:@"name"]];
            
        const char *update_stmt = [updateSQL UTF8String];
        if(sqlite3_prepare_v2(friendDB, update_stmt, -1, &statement, NULL )){
            sqlite3_bind_text(statement, 1, [[dictionary valueForKey:@"name"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 13, [[dictionary valueForKey:@"name"] UTF8String], -1, SQLITE_TRANSIENT);
             sqlite3_bind_text(statement, 13, [[dictionary valueForKey:@"name"] UTF8String], -1, SQLITE_TRANSIENT);
        };
        if (sqlite3_step(statement) == SQLITE_DONE)
        {
                success = true;
        }else{
                success = false;
        }
    }
    return success;
}

@end
